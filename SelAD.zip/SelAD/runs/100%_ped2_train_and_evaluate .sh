python "../train2evaluate.py" --dataset_type ped2 --SelAD --budget 1 --epochs 10
