python "../train2evaluate.py" --dataset_type ped2
